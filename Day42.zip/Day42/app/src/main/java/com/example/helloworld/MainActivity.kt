package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnHello=findViewById<Button>(R.id.btnClick)
        val myListener=View.OnClickListener {
            val name=findViewById<EditText>(R.id.etName)
            Toast.makeText(this, getString(R.string.hello_string) +" " + name.text,
                Toast.LENGTH_LONG).show()
        }
        btnHello.setOnClickListener(myListener)

    }
   /* fun buttonClicked(view: View?){
        val name=findViewById<EditText>(R.id.etName)
        Toast.makeText(this, getString(R.string.hello_string) +" " + name.text,
        Toast.LENGTH_LONG).show()
    }*/
}