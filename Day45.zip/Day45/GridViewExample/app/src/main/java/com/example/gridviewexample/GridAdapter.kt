package com.example.gridviewexample

import android.content.Context
import android.content.res.TypedArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class GridAdapter(var countryNamesList: Array<String>,
                  var imageList: TypedArray, var context: Context): BaseAdapter() {
    lateinit var textViewCountryName:TextView
    lateinit var imageFlag: ImageView

    override fun getCount(): Int {
        return countryNamesList.count()
    }

    override fun getItem(p0: Int): Any? {
        return null
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val view: View=LayoutInflater.from(parent?.getContext())
            .inflate(R.layout.gridview_layout,parent,false)
        textViewCountryName=view.findViewById<TextView>(R.id.tvCountryName)
        imageFlag=view.findViewById<ImageView>(R.id.imageViewFlag)
        textViewCountryName.setText(countryNamesList[position])
        imageFlag.setImageResource(imageList.getResourceId(position,0))
        return view
    }

}