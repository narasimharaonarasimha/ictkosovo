package com.example.gridviewexample

import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView

class MainActivity : AppCompatActivity() {
    var gridView: GridView?=null
    lateinit var countryNamesList: Array<String>
    lateinit var imageList: TypedArray

    lateinit var  adapter:GridAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        gridView=findViewById(R.id.gridViewCountries)
        countryNamesList=getResources().getStringArray(R.array.countries)
        imageList=getResources().obtainTypedArray(R.array.flags)

        adapter=GridAdapter(countryNamesList,imageList,this)
        gridView?.setAdapter(adapter)

    }
}