package com.example.recyclerviewdemo

import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private var recyclerView: RecyclerView? = null
    lateinit var countryNamesList: Array<String>
    lateinit var detailsList: Array<String>
    lateinit var imageList: TypedArray
    lateinit var adapter: RecyclerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView=findViewById<RecyclerView>(R.id.recyclerViewCountries)
        recyclerView?.setLayoutManager(LinearLayoutManager(this))
        countryNamesList = getResources().getStringArray(R.array.countries)
        detailsList = getResources().getStringArray(R.array.description)
        imageList = getResources().obtainTypedArray(R.array.flags)

        adapter = RecyclerAdapter(countryNamesList, detailsList, imageList, this)

        recyclerView?.setAdapter(adapter)



    }
}