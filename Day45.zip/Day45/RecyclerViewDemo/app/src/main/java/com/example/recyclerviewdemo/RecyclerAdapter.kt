package com.example.recyclerviewdemo

import android.content.Context
import android.content.res.TypedArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter(
    var countryNamesList: Array<String>,
    var detailsList: Array<String>, var imageList: TypedArray, var context: Context
): RecyclerView.Adapter<RecyclerAdapter.CountryViewHolder>() {
    class CountryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        lateinit var tvCountryName: TextView
        lateinit var tvDetails: TextView
        lateinit var imageFlag: ImageView
        init {
            tvCountryName=itemView.findViewById<TextView>(R.id.tvCountryName)
            tvDetails=itemView.findViewById<TextView>(R.id.tvCountryDescription)
            imageFlag=itemView.findViewById<ImageView>(R.id.profile_image)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view=LayoutInflater.from(parent.getContext())
            .inflate(R.layout.card_design,parent,false)
        return CountryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.tvCountryName.setText(countryNamesList[position])
        holder.tvDetails.setText(detailsList[position])
        holder.imageFlag.setImageResource(imageList.getResourceId(position,0))
    }

    override fun getItemCount(): Int {
        return countryNamesList.count()
    }

}