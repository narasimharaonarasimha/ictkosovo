package com.example.recyclerviewexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.res.TypedArray
import androidx.recyclerview.widget.LinearLayoutManager

import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private var recyclerView: RecyclerView?=null
    lateinit var countryNameList: Array<String>
    lateinit var detailsList: Array<String>
    lateinit var imageList: TypedArray
    lateinit private var adapter: RecyclerAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView=findViewById<RecyclerView>(R.id.recyclerViewCountries);
        recyclerView?.setLayoutManager( LinearLayoutManager(this));
        countryNameList=getResources().getStringArray(R.array.countries);
        detailsList=getResources().getStringArray(R.array.description);
        imageList=getResources().obtainTypedArray(R.array.flags);
        adapter = RecyclerAdapter(countryNameList, detailsList, imageList, this@MainActivity)
        recyclerView?.setAdapter(adapter)

    }
}