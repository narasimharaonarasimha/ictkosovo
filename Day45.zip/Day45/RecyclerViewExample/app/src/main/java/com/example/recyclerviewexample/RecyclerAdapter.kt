package com.example.recyclerviewexample

import android.content.Context
import android.content.res.TypedArray
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewexample.RecyclerAdapter.CountryViewHolder


import android.view.LayoutInflater
import androidx.cardview.widget.CardView
import android.widget.Toast





class RecyclerAdapter(var countryNameList: Array<String>, var detailsList: Array<String>,
                      var imageList: TypedArray, var context: Context
): RecyclerView.Adapter<RecyclerAdapter.CountryViewHolder>() {
    public class CountryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        lateinit var textViewCountryName: TextView
        lateinit var textViewDetails: TextView
        lateinit var imageFlag: ImageView
        lateinit var cardView: CardView
        init {
            textViewCountryName = itemView.findViewById<View>(R.id.textViewCountryName) as TextView
            textViewDetails =
                itemView.findViewById<TextView>(R.id.textViewCountryDescription)
            imageFlag = itemView.findViewById<ImageView>(R.id.profile_image)
            cardView = itemView.findViewById<CardView>(R.id.cardViewCountries)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.card_design, parent, false)
        return CountryViewHolder(view)

    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.textViewCountryName?.setText(countryNameList[position]);
        holder.textViewDetails?.setText(detailsList[position]);
        holder.imageFlag?.setImageResource(imageList.getResourceId(position,0));
        holder.cardView.setOnClickListener {
            Toast.makeText(
                context, "You selected " + detailsList[position],
                Toast.LENGTH_SHORT
            ).show()
        }

    }

    override fun getItemCount(): Int {
        return countryNameList.count();
    }
}