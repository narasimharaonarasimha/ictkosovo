package com.example.activitylifecycleexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    private val TAG="MainActivity"
    private lateinit var etName: EditText
    private lateinit var tvNames: TextView
    private val TEXT_CONTENTS="TextContents"
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate: in")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etName=findViewById<EditText>(R.id.etName)
        tvNames=findViewById<TextView>(R.id.tvNames)
        tvNames.setText("")
        Log.d(TAG, "onCreate: out")
    }

    override fun onStart() {
        Log.d(TAG, "onStart: in")
        super.onStart()
        Log.d(TAG, "onStart: out")
    }

    override fun onStop() {
        Log.d(TAG, "onStop: in")
        super.onStop()
        Log.d(TAG, "onStop: out")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        Log.d(TAG, "onSaveInstanceState: in")
        outState.putString(TEXT_CONTENTS,tvNames.text.toString())
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState: out")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        Log.d(TAG, "onRestoreInstanceState: in")
        super.onRestoreInstanceState(savedInstanceState)
        val savedString=savedInstanceState.getString(TEXT_CONTENTS)
        tvNames.setText(savedString)
        Log.d(TAG, "onRestoreInstanceState: out")
    }

    override fun onResume() {
        Log.d(TAG, "onResume: in")
        super.onResume()
        Log.d(TAG, "onResume: out")
    }

    override fun onPause() {
        Log.d(TAG, "onPause: in")
        super.onPause()
        Log.d(TAG, "onPause: out")
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy: in")
        super.onDestroy()
        Log.d(TAG, "onDestroy: out")
    }
    fun onAddNameClicked(view: View){
        tvNames.append("\n${etName.text}")
    }
}