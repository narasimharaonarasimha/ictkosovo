package com.example.healthyrecipes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Recipe : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe)
    }
}