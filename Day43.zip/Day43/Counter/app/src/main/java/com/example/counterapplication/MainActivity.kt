package com.example.counterapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private var tvNumber: TextView?= null
    private var countClicks=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvNumber=findViewById<TextView>(R.id.tvNumber)
    }
    fun countClick(view: View){
        countClicks++
        tvNumber?.setText(countClicks.toString())
    }
    fun toastClick(view: View){
        Toast.makeText(this, "Welcome to ICT Kosovo",Toast.LENGTH_SHORT).show()
    }
}