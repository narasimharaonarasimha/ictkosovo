package com.example.firebaseauthenticationdemo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    var auth= FirebaseAuth.getInstance()
    lateinit var etEmail: EditText
    lateinit var etSigninPassword: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etEmail=findViewById(R.id.etEmail)
        etSigninPassword=findViewById(R.id.etPassword1)
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        if(currentUser != null){
            intent= Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    fun signin(view: android.view.View) {
        var email=etEmail.text.toString()
        var password=etSigninPassword.text.toString()
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(this,"Signin Success",
                        Toast.LENGTH_SHORT).show()

                    intent= Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(baseContext, "Authentication failed.",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }
    fun signup(view: android.view.View) {
        intent= Intent(this, SignUp::class.java)
        startActivity(intent)
        finish()

    }

    fun forgot_password(view: android.view.View) {
        intent= Intent(this, ForgotPassword::class.java)
        startActivity(intent)
        finish()
    }
}