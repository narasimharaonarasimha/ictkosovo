package com.example.firebaseauthenticationdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class ForgotPassword : AppCompatActivity() {
    var auth= FirebaseAuth.getInstance()
    lateinit var etForgotEmailAddress: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        etForgotEmailAddress=findViewById(R.id.etForgotEmailAddress)
    }

    fun reset_password(view: android.view.View) {
        var emailAddress=etForgotEmailAddress.text.toString()
        auth.sendPasswordResetEmail(emailAddress)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this,"Email Sent",
                        Toast.LENGTH_SHORT).show()

                }
            }
    }
}