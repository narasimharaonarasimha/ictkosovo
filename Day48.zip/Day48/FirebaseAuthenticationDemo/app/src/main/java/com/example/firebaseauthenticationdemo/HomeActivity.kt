package com.example.firebaseauthenticationdemo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    var auth= FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }

    fun signout(view: android.view.View) {
        auth.signOut()
        intent= Intent(this,
            MainActivity::class.java)
        startActivity(intent)
        finish()

    }
}