package com.example.travelapp

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView

class CityAdapter(
    var context: Context?,
    var cityList: List<City>):
    RecyclerView.Adapter<CityAdapter.CityViewHolder>() {
    inner class CityViewHolder(itemView: View)
        : RecyclerView.ViewHolder(itemView) {
        fun setData(city: City, position: Int) {
            cityNameTextView.setText(city.name);
            cityImage.setImageResource(city.imageId);

            if (city.isFavorite) {
                favoriteImage.setImageDrawable(icFavoriteFilledImage);
            } else {
                favoriteImage.setImageDrawable(icFavoriteBorderedImage);
            }

            this.currentCity = city;
            this.currentPosition = position;

        }

        lateinit var cityNameTextView: TextView
        lateinit var cityImage: ImageView
        lateinit var favoriteImage:ImageView
        lateinit var deleteImage:ImageView
        var icFavoriteFilledImage: Drawable?
        var icFavoriteBorderedImage:Drawable?


        private var currentPosition = -1
        private var currentCity: City? = null
        init{
            cityNameTextView = itemView.findViewById(R.id.txv_city_name);
            cityImage = itemView.findViewById(R.id.imv_city);
            favoriteImage = itemView.findViewById(R.id.imv_favorite);
            deleteImage = itemView.findViewById(R.id.imv_delete);
            icFavoriteFilledImage = ResourcesCompat.getDrawable(context!!.resources, R.drawable.ic_favorite_filled,null)
            icFavoriteBorderedImage = ResourcesCompat.getDrawable(context!!.resources,
                R.drawable.ic_favorite_bordered, null);

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        val view: View =
            LayoutInflater.from(context)
                .inflate(R.layout.list_item_city, parent, false)
        return CityViewHolder(view)

    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        val city = cityList[position]
        holder.setData(city, position)

    }

    override fun getItemCount(): Int {
        return cityList.count()
    }
}
