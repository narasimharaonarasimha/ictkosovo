package com.example.travelapp

data class City(var imageId: Int, var name: String,
                var isFavorite:Boolean) {
}