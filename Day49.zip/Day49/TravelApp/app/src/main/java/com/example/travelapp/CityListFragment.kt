package com.example.travelapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class CityListFragment : Fragment() {
    lateinit var recyclerViewCities: RecyclerView
    lateinit var vacationSource: VacationSource

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_city_list, container, false)
        recyclerViewCities = view.findViewById<View>(R.id.city_recycler_view) as RecyclerView
        recyclerViewCities!!.layoutManager = LinearLayoutManager(context)
        recyclerViewCities!!.setHasFixedSize(true)
        vacationSource = VacationSource()
        val cityAdapter = CityAdapter(context, vacationSource.getCityList())
        recyclerViewCities!!.adapter = cityAdapter
        return view

    }
}