package com.example.demochatapp

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import de.hdodenhof.circleimageview.CircleImageView
import java.util.*

class SignUp : AppCompatActivity() {
    private lateinit var profileImage: CircleImageView
    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var editTextConfirmPassword: EditText
    var imageControl = false

    lateinit var auth: FirebaseAuth
    lateinit var database: FirebaseDatabase
    lateinit var dbreference: DatabaseReference

    lateinit var firebaseStorage: FirebaseStorage
    lateinit var storageReference: StorageReference
    lateinit var uri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        editTextName = findViewById(R.id.et_name);
        editTextEmail = findViewById(R.id.et_email_forgot);
        editTextPassword = findViewById(R.id.et_password);

        profileImage = findViewById(R.id.profile_image);
        val loadImage = registerForActivityResult(
            ActivityResultContracts.GetContent(), ActivityResultCallback {
                profileImage.setImageURI(it)
                uri = it
                imageControl = true

            }
        )
        profileImage.setOnClickListener({
            loadImage.launch("image/*")
        })

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        dbreference = database.reference;

        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();

    }

    fun signup_user(view: android.view.View) {
        val email = editTextEmail.text.toString()
        val password = editTextPassword.text.toString()
        val userName = editTextName.text.toString()

        signup(userName, email, password)

    }

    private fun signup(userName: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val user = auth.currentUser
                    dbreference.child("Users")
                        .child(auth.getUid()!!)
                        .child("userName")
                        .setValue(userName);
                    if (imageControl) {
                        val randomID: UUID = UUID.randomUUID()
                        val imageName = "images/$randomID.jpg"
                        storageReference.child(imageName).putFile(uri)
                        Toast.makeText(
                            this,
                            "Write to database successful",
                            Toast.LENGTH_SHORT
                        ).show()

                    }


                } else {
                    // If sign up fails, display a message to the user.
                    Toast.makeText(
                        baseContext, "Signup failed",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }


}
