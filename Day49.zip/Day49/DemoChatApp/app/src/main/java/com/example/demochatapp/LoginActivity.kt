package com.example.demochatapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var textViewForgotPassword:TextView
    private lateinit var textViewRegister: TextView
    lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        editTextEmail = findViewById(R.id.et_email);
        editTextPassword = findViewById(R.id.et_password);

        textViewRegister = findViewById(R.id.tv_register);
        textViewForgotPassword = findViewById(R.id.tv_forgot_password);

        auth = FirebaseAuth.getInstance();

    }
    fun register(view: android.view.View) {
        intent= Intent(this, SignUp::class.java)
        startActivity(intent)
    }
}