package com.example.samplemapdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : FragmentActivity(),OnMapReadyCallback {
    lateinit var map:GoogleMap
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var mapFragment=supportFragmentManager
            .findFragmentById(R.id.map)
                as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map=googleMap
        val pristina=LatLng(42.66231944216049,
            21.158896938973704)
        map.addMarker(
            MarkerOptions()
                .position(pristina)
                .title("New Born")

        )
        map.moveCamera(CameraUpdateFactory.newLatLng(pristina))
        map.animateCamera(CameraUpdateFactory.zoomTo(15F))
    }
}