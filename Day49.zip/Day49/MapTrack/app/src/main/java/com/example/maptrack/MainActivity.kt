package com.example.maptrack

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var etSource: EditText
    lateinit var etDestination:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etSource=findViewById(R.id.et_source)
        etDestination=findViewById(R.id.et_destination)
    }

    fun track(view: android.view.View) {
        val source=etSource.text.toString()
        val destination=etDestination.text.toString()
        //do validation later to check the edit text is not empty
        DisplayTrack(source, destination)
    }

    private fun DisplayTrack(source: String, destination: String) {
        val uri: Uri=Uri.parse("https://www.google.com/maps/dir/{$source}/{$destination}")
        val intent=Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }
}