package com.example.todoapp.data

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri
import android.util.Log
import com.example.todoapp.data.ToDoContract.CategoriesEntry
import com.example.todoapp.data.ToDoContract.TodosEntry

class ToDosProvider : ContentProvider() {
    //constants for the operation
    private val TODOS = 1
    private val TODOS_ID = 2
    private val CATEGORIES = 3
    private val CATEGORIES_ID = 4

    //urimatcher
    var uriMatcher = UriMatcher(UriMatcher.NO_MATCH)

    init {
        uriMatcher.addURI(
            TodosEntry.CONTENT_AUTHORITY,
            TodosEntry.PATH_TODOS, TODOS
        );
        uriMatcher.addURI(
            TodosEntry.CONTENT_AUTHORITY,
            TodosEntry.PATH_TODOS + "/#", TODOS_ID
        );
        uriMatcher.addURI(
            TodosEntry.CONTENT_AUTHORITY,
            CategoriesEntry.PATH_CATEGORIES, CATEGORIES
        );
        uriMatcher.addURI(
            TodosEntry.CONTENT_AUTHORITY,
            CategoriesEntry.PATH_CATEGORIES + "/#", CATEGORIES_ID
        );

    }

    private lateinit var helper: DatabaseHelper
    override fun onCreate(): Boolean {
        helper = DatabaseHelper(context)
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        //get db
        val db = helper.readableDatabase
        //cursor
        val cursor: Cursor
        //our integer
        val match = uriMatcher.match(uri)
        //intables – for joins
        val inTables = (TodosEntry.TABLE_NAME
                + " inner join "
                + CategoriesEntry.TABLE_NAME
                + " on " + TodosEntry.COLUMN_CATEGORY + " = "
                + CategoriesEntry.TABLE_NAME + "." + CategoriesEntry._ID)
        val builder: SQLiteQueryBuilder
        when (match) {
            TODOS -> {
                builder = SQLiteQueryBuilder()
                builder.tables = inTables
                cursor = builder.query(
                    db, projection, null,
                    null, null, null, sortOrder
                )
            }
            TODOS_ID -> {
                builder = SQLiteQueryBuilder()
                builder.tables = inTables
                val selectionClause = "${TodosEntry._ID}" + "=?"
                val selectionArguments = arrayOf(ContentUris.parseId(uri).toString())
                cursor = builder.query(
                    db, projection, selectionClause,
                    selectionArguments, null, null, sortOrder
                )
            }
            CATEGORIES -> cursor = db.query(
                CategoriesEntry.TABLE_NAME,
                projection, null, null, null,
                null, sortOrder
            )
            CATEGORIES_ID -> {
                val selectionClause = CategoriesEntry._ID + "=?"
                val selectionArguments = arrayOf(ContentUris.parseId(uri).toString())
                cursor = db.query(
                    CategoriesEntry.TABLE_NAME,
                    projection, selectionClause, selectionArguments, null,
                    null, sortOrder
                )
            }
            else -> throw IllegalArgumentException("Query unknown URI: $uri")
        }


        return cursor

    }

    override fun getType(p0: Uri): String? {
        TODO("Not yet implemented")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val match = uriMatcher.match(uri)
        return when (match) {
            TODOS -> insertRecord(uri, values, TodosEntry.TABLE_NAME)
            CATEGORIES -> insertRecord(uri, values, CategoriesEntry.TABLE_NAME)
            else -> throw IllegalArgumentException("Insert unknown URI: $uri")
        }

    }
    private fun insertRecord(uri: Uri, values: ContentValues?, table: String): Uri? {
        //this time we need a writable database
        val db = helper.writableDatabase
        val id = db.insert(table, null, values)
        if (id == -1L) {
            Log.e("Error", "insert error for URI $uri")
            return null
        }
        return ContentUris.withAppendedId(uri, id)
    }


    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        val match = uriMatcher.match(uri)
        return when (match) {
            TODOS -> deleteRecord(uri, null, null, TodosEntry.TABLE_NAME)
            TODOS_ID -> deleteRecord(uri, selection, selectionArgs, TodosEntry.TABLE_NAME)
            CATEGORIES -> deleteRecord(uri, null, null, CategoriesEntry.TABLE_NAME)
            CATEGORIES_ID -> deleteRecord(
                uri, selection, selectionArgs,
                CategoriesEntry.TABLE_NAME
            )
            else -> throw IllegalArgumentException("Insert unknown URI: $uri")
        }

    }
    private fun deleteRecord(
        uri: Uri,
        selection: String?,
        selectionArgs: Array<String>?,
        tableName: String
    ): Int {
        //this time we need a writable database
        val db = helper.writableDatabase
        val id = db.delete(tableName, selection, selectionArgs)
        if (id == -1) {
            Log.e("Error", "delete unknown URI $uri")
            return -1
        }
        return id
    }

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int {
        val match = uriMatcher.match(uri)
        return when (match) {
            TODOS -> updateRecord(uri, values, selection, selectionArgs, TodosEntry.TABLE_NAME)
            CATEGORIES -> updateRecord(
                uri,
                values,
                selection,
                selectionArgs,
                CategoriesEntry.TABLE_NAME
            )
            else -> throw IllegalArgumentException("Update unknown URI: $uri")
        }

    }
    private fun updateRecord(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?,
        tableName: String
    ): Int {
        //this time we need a writable database
        val db = helper.writableDatabase
        val id = db.update(tableName, values, selection, selectionArgs)
        if (id == 0) {
            Log.e("Error", "update error for URI $uri")
            return -1
        }
        return id
    }
}