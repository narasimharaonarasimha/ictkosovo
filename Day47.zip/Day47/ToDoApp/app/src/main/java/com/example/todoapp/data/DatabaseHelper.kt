package com.example.todoapp.data

import android.content.Context
import android.database.DatabaseErrorHandler
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.todoapp.data.ToDoContract.CategoriesEntry
import com.example.todoapp.data.ToDoContract.TodosEntry

class DatabaseHelper(
    context: Context?,
    name: String?="todos.db",
    factory: SQLiteDatabase.CursorFactory?=null,
    version: Int=1
) : SQLiteOpenHelper(context, name, factory, version) {
    //SQL to create tables – CODE in Canvas
    private val TABLE_CATEGORIES_CREATE = "CREATE TABLE " + CategoriesEntry.TABLE_NAME + " (" +
            CategoriesEntry._ID + " INTEGER PRIMARY KEY, " +
            CategoriesEntry.COLUMN_DESCRIPTION + " TEXT " +
            ")"
    private val TABLE_TODOS_CREATE = ("CREATE TABLE " + TodosEntry.TABLE_NAME + " (" +
            TodosEntry._ID + " INTEGER PRIMARY KEY, " +
            TodosEntry.COLUMN_TEXT + " TEXT, " +
            TodosEntry.COLUMN_CREATED + " TEXT default CURRENT_TIMESTAMP, " +
            TodosEntry.COLUMN_EXPIRED + " TEXT, " +
            TodosEntry.COLUMN_DONE + " INTEGER, " +
            TodosEntry.COLUMN_CATEGORY + " INTEGER, " +
            " FOREIGN KEY(" + TodosEntry.COLUMN_CATEGORY + ") REFERENCES " + CategoriesEntry.TABLE_NAME
            + "(" + CategoriesEntry._ID + ") " + ")")

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(TABLE_CATEGORIES_CREATE)
        db?.execSQL(TABLE_TODOS_CREATE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS " +TodosEntry.TABLE_NAME)
        db?.execSQL("DROP TABLE IF EXISTS " +CategoriesEntry.TABLE_NAME)
        onCreate(db)
    }

}