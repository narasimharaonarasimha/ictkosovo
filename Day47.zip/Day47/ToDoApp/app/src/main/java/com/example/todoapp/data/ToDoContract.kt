package com.example.todoapp.data

import android.net.Uri
import android.provider.BaseColumns

class ToDoContract {
    object TodosEntry: BaseColumns {

        //URI section
        val CONTENT_AUTHORITY = "com.example.todoapp.todosprovider"
        val BASE_CONTENT_URI: Uri = Uri.parse("content://$CONTENT_AUTHORITY")
        val PATH_TODOS = "todos"
        val CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_TODOS)
        // Table name
        val TABLE_NAME = "todos"

        //column (field) names
        val _ID = BaseColumns._ID
        val COLUMN_TEXT = "text"
        val COLUMN_CREATED = "created"
        val COLUMN_EXPIRED = "expired"
        val COLUMN_DONE = "done"
        val COLUMN_CATEGORY = "category"

    }
    object CategoriesEntry : BaseColumns {
        //URI section
        val CONTENT_AUTHORITY = "com.example.todoapp.todosprovider"
        val BASE_CONTENT_URI: Uri = Uri.parse("content://$CONTENT_AUTHORITY")
        val PATH_CATEGORIES = "categories"
        val CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_CATEGORIES)


        // Table name
        const val TABLE_NAME = "categories"

        //column names
        const val _ID = BaseColumns._ID
        const val COLUMN_DESCRIPTION = "description"

    }
}