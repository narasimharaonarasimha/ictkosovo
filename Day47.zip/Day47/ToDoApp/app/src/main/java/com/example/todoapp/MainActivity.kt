package com.example.todoapp

import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.util.Log
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.ListView
import com.example.todoapp.data.DatabaseHelper
import com.example.todoapp.data.ToDoContract
import com.example.todoapp.data.ToDoContract.TodosEntry
import com.example.todoapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding


    var itemname=arrayOf("Get theater tickets",
    "Order pizza for tonight",
    "Buy groceries",
    "Running session at 1830",
    "Call John")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        val lv: ListView=findViewById(R.id.lvTodos)

        lv.setAdapter(
            ArrayAdapter(this, R.layout.todo_list_item,R.id.tvNote,itemname)
        )
        //add an onclick listener for the listview
        lv.setOnItemClickListener { adapterView, view, pos, id ->
            val intent= Intent(this,ToDoActivity::class.java)
            val content=lv.getItemAtPosition(pos) as String
            intent.putExtra("Content", content)
            startActivity(intent)
        }
        CreateCategory()
        //CreateTodo()
        //readData()
        //updateTodo()
        //deleteTodo()
       // val helper=DatabaseHelper(this)
       // val db=helper.readableDatabase
       /* binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }*/
    }
    private fun updateTodo() {
        val id = 1
        val helper = DatabaseHelper(this)
        val db = helper.readableDatabase
        val args = arrayOf(id.toString())
        val values = ContentValues()
        values.put(TodosEntry.COLUMN_TEXT, "Order Cake")
        val numRows = db.update(TodosEntry.TABLE_NAME, values, TodosEntry._ID + " =?", args)
        Log.d("Update Rows", numRows.toString())
        db.close()
    }
    private fun deleteTodo() {
        val id = 1
        val helper = DatabaseHelper(this)
        val db = helper.readableDatabase
        val args = arrayOf(id.toString())
        val numRows = db.delete(TodosEntry.TABLE_NAME, TodosEntry._ID + " =?", args)
        Log.d("Delete Rows", numRows.toString())
    }

    private fun readData() {
        val helper = DatabaseHelper(this)
        val db = helper.readableDatabase
        val projection = arrayOf(
            TodosEntry.COLUMN_TEXT,
            TodosEntry.COLUMN_CREATED,
            TodosEntry.COLUMN_EXPIRED,
            TodosEntry.COLUMN_DONE,
            TodosEntry.COLUMN_CATEGORY
        )
        val selection = TodosEntry.COLUMN_CATEGORY + " = ?"
        val selectionArgs = arrayOf("1")
        val c: Cursor = db.query(
            TodosEntry.TABLE_NAME,
            projection, selection, selectionArgs, null, null, null
        )
        var i: Int = c.getCount()
        Log.d("Record Count", i.toString())
        var rowContent = ""
        while (c.moveToNext()) {
            i = 0
            while (i <= 4) {
                rowContent += c.getString(i).toString() + " - "
                i++
            }
            Log.i("Row " + java.lang.String.valueOf(c.getPosition()), rowContent)
            rowContent = ""
        }
        c.close()
    }
    private fun CreateCategory() {
        val values = ContentValues()
        values.put(ToDoContract.CategoriesEntry.COLUMN_DESCRIPTION, "Work")
        val uri: Uri? = contentResolver.insert(
            ToDoContract.CategoriesEntry.CONTENT_URI,
            values
        )
        Log.d("MainActivity", "Inserted note $uri")
    }
    private fun CreateTodo() {
        val helper = DatabaseHelper(this)
        val db = helper.writableDatabase
        val query = ("INSERT INTO todos ("
                + TodosEntry.COLUMN_TEXT + ","
                + TodosEntry.COLUMN_CATEGORY + ","
                + TodosEntry.COLUMN_CREATED + ","
                + TodosEntry.COLUMN_EXPIRED + ","
                + TodosEntry.COLUMN_DONE + ")"
                + " VALUES (\"Go to the gym\", 1, \"2021-07-03\", \"\", 0)")
        db.execSQL(query)

        val values = ContentValues()
        values.put(TodosEntry.COLUMN_TEXT, "Order Pizzas")
        values.put(TodosEntry.COLUMN_CATEGORY, 1)
        values.put(TodosEntry.COLUMN_CREATED, "2021-01-02")
        values.put(TodosEntry.COLUMN_DONE, 0)
        val todo_id = db.insert(TodosEntry.TABLE_NAME, null, values)

    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_categories -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

}