package com.example.cafeapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*


class OrderActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private val EXTRA_MESSAGE = "ExtraMessage"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)
        val message = intent.getStringExtra(EXTRA_MESSAGE)
        val textView = findViewById<TextView>(R.id.order_status)
        textView.text = message
        val spinner = findViewById<Spinner>(R.id.label_spinner)
        spinner.setOnItemSelectedListener(this)
        var adapter = ArrayAdapter.createFromResource(
            this, R.array.labels_array,
            R.layout.support_simple_spinner_dropdown_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    fun onRadioButtonClicked(view: View) {
        val checked = (view as RadioButton).isChecked
        when (view.getId()) {
            R.id.rbSameDay -> if (checked) {
                displayToast(getString(R.string.same_day_messenger_service_text))
            }
            R.id.rbNextDay -> if (checked) {
                displayToast(getString(R.string.next_day_ground_delivery_text))
            }
            R.id.rbPickup -> if (checked) {
                displayToast(getString(R.string.pick_up_text))
            }
        }
    }

    fun displayToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onItemSelected(parent: AdapterView<*>, p1: View?, position: Int, p3: Long) {
        val spinnerLabel = parent.getItemAtPosition(position).toString()
        displayToast(spinnerLabel)
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}