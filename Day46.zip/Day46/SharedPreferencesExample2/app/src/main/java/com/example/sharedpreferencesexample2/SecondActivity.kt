package com.example.sharedpreferencesexample2

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    private lateinit var textViewID: TextView
    private lateinit var textViewName: TextView
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        textViewID=findViewById(R.id.textViewStudentID)
        textViewName=findViewById(R.id.textViewStudentName)
    }

    fun loadDataFromMain(view: android.view.View) {
        sharedPreferences=getSharedPreferences("$packageName.student_info",
            Context.MODE_PRIVATE)
        //sharedPreferences.getBoolean("page_color",false)
        textViewID.text=sharedPreferences.getInt("student_id",0).toString()
        textViewName.text=sharedPreferences.getString("student_name",null)
    }
}