package com.example.sharedpreferencesexample2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var editTextID: EditText
    private lateinit var editTextName: EditText
    private lateinit var textViewID: TextView
    private lateinit var textViewName: TextView
    private lateinit var pageColorSwitch: Switch
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editTextID=findViewById(R.id.editTextStudentID)
        editTextName=findViewById(R.id.editTextStudentName)
        textViewID=findViewById(R.id.textViewStudentID)
        textViewName=findViewById(R.id.textViewStudentName)
        pageColorSwitch=findViewById(R.id.pageColorSwitch)
        //pageColorSwitch.setOnCheckedChangeListener(View.On
    }


    fun saveData(view: android.view.View) {
        sharedPreferences=getSharedPreferences("$packageName.student_info",
        Context.MODE_PRIVATE)
        val editor=sharedPreferences.edit()
        //editor.putBoolean("page_color",pageColorSwitch.isChecked)
        editor.putInt("student_id",Integer.valueOf(editTextID.text.toString()))
        editor.putString("student_name",editTextName.text.toString())
        editor.commit()

    }
    fun loadData(view: android.view.View) {
        sharedPreferences=getSharedPreferences("$packageName.student_info",
            Context.MODE_PRIVATE)
        //sharedPreferences.getBoolean("page_color",false)
        textViewID.text=sharedPreferences.getInt("student_id",0).toString()
        textViewName.text=sharedPreferences.getString("student_name",null)

    }
    fun openSecondActivity(view: android.view.View) {
        var intent= Intent(this,SecondActivity::class.java)
        startActivity(intent)
    }
}