package com.example.sharedpreferencesexample3

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.gson.Gson

class MainActivity : AppCompatActivity() {
    private lateinit var tvDisplay:TextView
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvDisplay=findViewById(R.id.textViewDisplayData)
    }

    fun saveData(view: android.view.View) {
        var emails: MutableList<String> =ArrayList()
        emails.add("john@gmail.com")
        emails.add("john@yahoo.com")
        val employee=Employee(123,"John", emails)

        sharedPreferences=getPreferences(Context.MODE_PRIVATE)
        val editor=sharedPreferences.edit()
        val gson= Gson()
        val jsonString=gson.toJson(employee,Employee::class.java)
        editor.putString("employee_key", jsonString)
        editor.apply()

    }
    fun loadData(view: android.view.View) {
        sharedPreferences=getPreferences(Context.MODE_PRIVATE)
        var jsonString=sharedPreferences.getString("employee_key", null)
        val gson= Gson()
        val employee:Employee=gson.fromJson(jsonString, Employee::class.java)
        tvDisplay.setText("${employee}")
    }
}