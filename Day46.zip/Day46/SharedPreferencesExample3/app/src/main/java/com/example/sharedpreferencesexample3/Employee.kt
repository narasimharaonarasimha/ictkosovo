package com.example.sharedpreferencesexample3

data class Employee(var empID: Int, var empName: String, var emails: List<String>) {
}