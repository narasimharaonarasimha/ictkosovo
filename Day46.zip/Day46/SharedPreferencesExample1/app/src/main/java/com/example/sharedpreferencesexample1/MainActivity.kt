package com.example.sharedpreferencesexample1

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private lateinit var editTextName:EditText
    private lateinit var editTextAddress: EditText
    private lateinit var buttonCount: Button
    private lateinit var checkBoxRemember: CheckBox
    private var count=0
    private var status=false
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editTextName=findViewById(R.id.editTextName)
        editTextAddress=findViewById(R.id.editTextAddress)
        buttonCount=findViewById(R.id.buttonCount)
        checkBoxRemember=findViewById(R.id.checkBoxRemember)
        restoreData()
    }

    private fun restoreData() {
        sharedPreferences=getSharedPreferences("saveData", Context.MODE_PRIVATE)
        editTextName.setText(sharedPreferences.getString("name", null))
        editTextAddress.setText(sharedPreferences.getString("address", null))
        buttonCount.text=sharedPreferences.getInt("count",0).toString()
        status=sharedPreferences.getBoolean("status", false)
        if(status)
            checkBoxRemember.isChecked=true
        else
            checkBoxRemember.isChecked=false
    }

    override fun onPause() {
        saveData()
        super.onPause()
    }

    private fun saveData() {
        sharedPreferences=getSharedPreferences("saveData", Context.MODE_PRIVATE)
        val editor=sharedPreferences.edit()
        editor.putString("name",editTextName.text.toString())
        editor.putString("address",editTextAddress.text.toString())
        editor.putInt("count", count)
        status=if(checkBoxRemember.isChecked) true else false
        editor.putBoolean("status", status)
        editor.apply() //editor.commit()
    }

    fun countValues(view: android.view.View) {
        count++
        buttonCount.text="$count"
    }
}