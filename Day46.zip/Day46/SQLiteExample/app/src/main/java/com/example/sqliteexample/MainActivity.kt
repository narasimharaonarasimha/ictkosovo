package com.example.sqliteexample

import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sqlLiteDatabase =baseContext.openOrCreateDatabase("testdb.db",
        MODE_PRIVATE,null)
        var sql="drop table if exists contacts"
        sqlLiteDatabase.execSQL(sql)

        sql="create table if not exists contacts (name text, phone integer, email text);"
        sqlLiteDatabase.execSQL(sql)

        sql="insert into contacts values('john',123123,'john@gmail.com')";
        sqlLiteDatabase.execSQL(sql)

        sql="insert into contacts values('jack',345345,'jack@gmail.com')";
        sqlLiteDatabase.execSQL(sql)


        sql="select * from contacts;"
        var query: Cursor =sqlLiteDatabase.rawQuery(sql, null)

        if(query.moveToFirst()){
            do{
                val name:String=query.getString(0)
                val phone:Int=query.getInt(1)
                val email:String=query.getString(2)
                Toast.makeText(this,"$name $phone $email",
                    Toast.LENGTH_SHORT).show()
            }while(query.moveToNext())
        }
        query.close()
        sqlLiteDatabase.close()

    }
}